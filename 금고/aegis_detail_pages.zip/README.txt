[이지스(AEGIS) 상세페이지 - 개발 전달용]

구성
- SFS10046_이지스_74L/   index.html + images
- SFS10048_이지스_100L/  index.html + images
- SFS10049_이지스_122L/  index.html + images
- SFS10052_이지스_411L/  index.html + images

방식
- 모든 문구는 실제 HTML 텍스트(SEO). SVG 라인 아이콘 사용.
- FAQ/제품표/배송·설치·교환·AS 안내는 실제 HTML(자동 줄바꿈).
- 히어로 = 각 제품 컷(흰 배경), 컬러 라인업·내화 이미지는 AEGIS 라인 공용.

적용 (카페24)
1) 각 제품 images/ 파일을 쇼핑몰 이미지 서버에 업로드
2) index.html 의 src="images/..." 경로를 업로드된 실제 URL로 일괄 변경
3) 상세 편집 HTML 모드에 <div class="safe"> ~ </div> + 상단 <style> + <link>(Pretendard) 붙여넣기
4) 상세영역 폭이 넓으면 .safe{ max-width } 값 조정 (기본 860px)

스펙 (확정)
- 74L : 내부 539x397x344 / 외부 768x552x549 / 129kg
- 100L: 내부 680x426x344 / 외부 909x581x549 / 159kg
- 122L: 내부 833x426x344 / 외부 1062x581x549 / 187kg
- 411L: 내부 1524x578x467 / 외부 1769x733x688 / 405kg

참고
- 계단 운반비/설치비/CS번호(1588-3112)는 다이렉트몰 기준값 확인 후 확정하세요.
- 도어 컬러: 화이트/블랙/레드/우드 4종 택1.
