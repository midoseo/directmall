[메타큐브1 상세페이지 - 개발 전달용]

구성
- SFS10045_메타큐브1_20L/  (index.html + images)
- SFS10047_메타큐브1_40L/  (index.html + images)

방식
- 모든 문구는 실제 HTML 텍스트(SEO). SVG 라인 아이콘 사용.
- 내화 이미지는 애니메이션 GIF (fire.gif).
- FAQ/제품표/배송·AS 안내는 실제 HTML(자동 줄바꿈).

적용 (카페24)
1) 각 제품 images/ 파일을 쇼핑몰 이미지 서버에 업로드
2) index.html 의 src="images/..." 경로를 업로드된 실제 URL로 일괄 변경
3) 상세 편집 HTML 모드에 <div class="safe"> ~ </div> + 상단 <style> + <link>(Pretendard) 붙여넣기
4) 상세영역 폭이 넓으면 .safe{ max-width } 값 조정 (기본 860px)

참고
- 계단 운반비/설치비/CS번호(1588-3112) 등은 다이렉트몰 기준값 확인 후 확정하세요.
